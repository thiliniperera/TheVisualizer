These files were extracted from GADM version 1.0, in March 2009

GADM is a geographic database of global administrative areas (boundaries). 

This work is licensed under a Creative Commons Attribution-Noncommercial-Share Alike 3.0 United States License.
This only covers our contribution, not that of others (data provided to us). 

Visit http://www.gadm.org for details

